import { Component, OnInit, ViewChild, Input } from '@angular/core';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {
  @ViewChild('dropdown',{static : false}) dropDownRef;
  @Input() selectedRecipe;
  showList = false;
  constructor() { }

  ngOnInit() {
    console.log(this.selectedRecipe);
  }

  onClickManageRecipe(){
    this.showList = !this.showList;
    if(this.showList){
      this.dropDownRef.nativeElement.classList.add('show');
    }
    else{
      this.dropDownRef.nativeElement.classList.remove('show');
    }
  }
}
