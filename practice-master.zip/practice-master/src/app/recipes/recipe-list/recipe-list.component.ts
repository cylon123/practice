import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Recipe } from '../recipe.model';
 
@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {

  constructor() { }
  
  @Output('Recip') selectedRecipe = new EventEmitter<any>();

  recipes : Recipe[] = [ new Recipe('Test Recipe',
  'This is a test Recipe',
  '../../../assets/recipe.jpg') ,
  new Recipe('Test Recipe 1',
  'This is a test Recipe 1',
  '../../../assets/recipe.jpg')
]
onRecipeClick(recipe){
  this.selectedRecipe.emit(recipe);
}
  ngOnInit() {
  }
}
