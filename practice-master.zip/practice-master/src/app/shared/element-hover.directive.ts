import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appElementHover]'
})
export class ElementHoverDirective {

  constructor( el : ElementRef) { 
    console.dir(el.nativeElement);
  }
}
